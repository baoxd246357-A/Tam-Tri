# Hướng dẫn gộp Tam-Tri vào dự án khác

Gói này gồm mã nguồn + tài liệu (không có database, ảnh upload, file .env/API key).

## Cấu trúc
- app/main.py          FastAPI + SQLAlchemy (SQLite) + Gemini (google-genai): visits, photos, AI analyze, voice evidence, daily report
- app/templates/index.html, app/static/style.css   giao diện mobile
- docs/stone-mapping-shopdrawing.md   thiết kế module Map đá & Shopdrawing (chưa code)
- requirements.txt, render.yaml, DEPLOY-RENDER.md

## Cách gộp
1. Copy thư mục `app/` vào dự án đích (hoặc mount như sub-app: `parent.mount("/site", app)`).
2. Gộp `requirements.txt`: fastapi, uvicorn[standard], python-multipart, jinja2, sqlalchemy, pydantic, google-genai, python-dotenv.
3. Tạo `.env` ở gốc dự án đích với khoá Gemini (`GEMINI_API_KEY=...` và tuỳ chọn `GEMINI_MODEL`).
4. Dữ liệu chạy ở `data/` (site_control.db, uploads/, evidence/) tự tạo khi chạy; copy thư mục này nếu muốn mang theo dữ liệu cũ.
5. Xung đột cần kiểm tra: tên bảng (projects, site_visits, photos, voice_evidence), route `/api/v1/...`, `Base`/`engine` nếu dự án đích đã có.
